<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product; 
use App\Models\Cart; 
 use App\Http\UserAuth;


class ProductController extends Controller
{
    function index()
    {
        $data=Product::all();
        return view('product',['products'=>$data]);
    }

function detail($id)
{
    $data=Product::find($id);
    return view('detail',['product'=>$data]);
}
function search(Request $req)
{
    $data= Product::
    where('name', 'like', '%'.$req->input('query').'%')
    ->get();
    return view('search',['products'=>$data]);
}
function addToCart(Request $req)
    {
        if(Auth::id()){
            $user=auth()->user();
            $products=Product::find($id);
            $cart=new Cart;
            $cart->product_id=$products->id;
            $cart->user_id=$user->id;
            $cart->name=$user->name;
            $cart->save();
           
        return  redirect('/');


        }
        else
        {
            return redirect('/login');
        }
    }
    
}

