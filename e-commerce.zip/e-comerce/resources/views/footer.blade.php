<div style="clear:both" class="panel panel-default">
<div class="panel-body">
    Panel curl_multi_getcontent</div>
<div class="panel-footer">Panel footer</div>
</div>
