<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('products')->insert([
           [
            "name"=>"Oppo mobile",
            "price"=>"50000",
            "category"=>"mobile",
            "description"=>"A smartphone with 4gb ram and more features",
             "gallery"=>"https://www.godigit.com/content/dam/godigit/directportal/en/contenthm/oppo-a55.jpg"
           ],
           [
           "name"=>"Panasonic Tv",
           "price"=>"300000",
           "category"=>"tv",
           "description"=>"A tv with more features",
            "gallery"=>"https://media.ldlc.com/r1600/ld/products/00/05/84/97/LD0005849719_1.jpg"
           ],
           [
            "name"=>"Soni tv",
            "price"=>"500000",
            "category"=>"tv",
            "description"=>"A tv with more features",
             "gallery"=>"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfXN2jc2js0jl7XqRE3wb8SacSDLSwRTpp5oiyxQp-MKA72qCPA26UDBbxW7uSKjZdMhI&usqp=CAU"
           ],
           [
            "name"=>"LG fridge",
            "price"=>"800000",
            "category"=>"fridge",
            "description"=>"A fridge with more features",
             "gallery"=>"https://static.wixstatic.com/media/2cd43b_3c1c1d30b99343acb96ba81a81021ed8~mv2.png/v1/fill/w_320,h_371,q_90/2cd43b_3c1c1d30b99343acb96ba81a81021ed8~mv2.png"
           ]
        ]);
    }
}
